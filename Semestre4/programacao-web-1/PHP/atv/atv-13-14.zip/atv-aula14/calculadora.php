<?php
class calculadora{
    
    public function soma($a, $b):float{
        return $a + $b;
    }

    public function subtracao($a, $b):float{
        return $a - $b;
    }

    public function multiplicacao($a, $b):float{
        return $a * $b;
    }

    public function divisao($a, $b):float{
        return $a / $b;
    }

}
?>