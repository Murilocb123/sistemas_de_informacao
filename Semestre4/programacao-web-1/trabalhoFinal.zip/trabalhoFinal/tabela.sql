CREATE TABLE cliente (
    codigo INT,
    nome VARCHAR(50),
    sobrenome VARCHAR(50),
    data_nascimento DATE,
    email VARCHAR(100)
);
