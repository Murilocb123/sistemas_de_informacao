# Trabalho Final da disciplina de Progrmação Web 1

## Descrição do Projeto

1 - Deverá possuir uma tela de login e ao informar as credenciais de acesso, deverá criar uma sessão para o usuário (2.0)
2 - Deverá permitir cadastrar clientes com os seguintes campos: Código, Nome, Sobrenome, Data de Nascimento, Endereço de e-Mail (2.0)
3 - Deverá disponibilizar uma opção para listar os clientes cadastrados, sendo exibidos em uma lista formatada como tabela. (2.0)
4 - A listagem deverá permitir informar um nome para filtro por aproximação (iLike) no SGBD, retornando apenas aquelas pessoas cuja o nome contém o valor informado no filtro. (2.0)
5 - Deverá apresentar um visual de fácil utilização (2.0)

## Dados de Acesso
USUÁRIO: admin
SENHA: admin

## Dados banco de dados
HOST: 127.0.0.1
PORTA: 5432
USUÁRIO: postgres
SENHA: 123456
BANCO: trabalhoFinal