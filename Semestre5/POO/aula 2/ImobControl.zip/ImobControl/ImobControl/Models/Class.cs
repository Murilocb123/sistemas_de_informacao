﻿namespace ImobControl.Models
{
    public class Class
    {
    }
}
